package com.ct.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.web.servlet.ModelAndView;

//import com.ct.Model.Vehicle;
import com.ct.dbConnection.DbConnection;
import co.ct.model.Customer;
import co.ct.model.Vehicle;



public class DaoVehicle {

	
	
	public String register(Customer custNew) {
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
		Transaction tr=session.getTransaction();
		String msg="";
	
		session.save(custNew);
		tr.commit();
		//session.close();
		msg="customer is registered now log in";
		
		
		return msg;
	}

	public boolean login(Customer custNew) {
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
		Transaction tr=session.getTransaction();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.eq("userName",custNew.getUserName()));
		criteria.add(Restrictions.eq("password",custNew.getPassword()));
		criteria.add(Restrictions.eq("role",custNew.getRole()));
		List<Customer> loginList = criteria.list();
		session.close();
		if(loginList.isEmpty()) {
			return false;
		}
		else {
			return true;
		}
	
	/*	Customer cust=(Customer)session.get(Customer.class,new Integer(1));
		tr.commit();
		//session.close();
		if(cust!=null) {
			return true;
		}
		
		else {
			return false;
		}*/
	}

	public String addVehicle(Vehicle vehicle) {
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
	
		Transaction tr=session.getTransaction();
		
		session.save(vehicle);
		tr.commit();
		session.close();
		String message="Vehicle is added";
		return message;
		}

	public String deleteVehicle(Vehicle vehicle) {
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
		Transaction tr=session.getTransaction();
		vehicle=(Vehicle)session.get(Vehicle.class,vehicle.getVcode());
		session.delete(vehicle);
		tr.commit();
		session.close();
		String message="Vehicle is deleted";
		return message;
		
	}

	public Vehicle getVehicleById(Vehicle vehicle) {
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
		Transaction tr=session.getTransaction();
		vehicle=(Vehicle)session.get(Vehicle.class,vehicle.getVcode());
		tr.commit();
		session.close();
		return vehicle;
		}
	
	public List<Vehicle> displayAll()
	{
		/*Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction transaction = session.getTransaction();
		
		Criteria criteria = session.createCriteria(Login.class);
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(Restrictions.eq("username",login.getUsername()));
		disjunction.add(Restrictions.eq("password",login.getPassword()));
		disjunction.add(Restrictions.eq("role",login.getRole()));
		criteria.add(disjunction);
		List<Login> loginList = criteria.list();
		if(loginList.isEmpty()) {
			return false;
		}
		else {
			return true;
		}*/
		
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
		Transaction tr=session.getTransaction();
        String que="select * from Vehicle";
        SQLQuery sql=  session.createSQLQuery(que);
        sql.addEntity(Vehicle.class);
        List<Vehicle> result=sql.list();
        tr.commit(); 
        session.close();
		return result;
	}
	
	public boolean ifusernameexist(Customer cusName) {
		
		Session session= DbConnection.getSessionFactory();
		session.beginTransaction();
		Transaction tr=session.getTransaction();
		
		
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.eq("userName",cusName.getUserName()));
	
		List<Customer> userexistlist = criteria.list();
		session.close();
		if(userexistlist.isEmpty()) {
			return true;
		}
		else {
			return false;
		}
}
}
