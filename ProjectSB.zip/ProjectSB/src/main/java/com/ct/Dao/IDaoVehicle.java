/*package com.ct.Dao;

import com.ct.Model.Customer;
import com.ct.Model.Vehicle;

public interface IDaoVehicle {

	public String register(Customer cust);
	public boolean login(Customer cust);
	public String addVehicle(Vehicle vehicle);
	public String deleteVehicle(Vehicle vehicle);
	public Vehicle getVehicleById(Vehicle vehicle);
	
}
*/