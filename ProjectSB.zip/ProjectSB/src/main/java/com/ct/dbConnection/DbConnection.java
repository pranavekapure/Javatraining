package com.ct.dbConnection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class DbConnection {
	public static SessionFactory sessionFactory;
	
	public static Session getSessionFactory() {
		Configuration configuration = new Configuration().configure();
        ServiceRegistry serviceRegistry= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
         // builds a session factory from the service registry
        sessionFactory = configuration.buildSessionFactory(serviceRegistry); 
        Session session=sessionFactory.openSession();
        return session;
	}
	
}
