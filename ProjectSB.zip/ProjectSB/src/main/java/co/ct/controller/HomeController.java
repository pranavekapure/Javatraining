package co.ct.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.ct.Dao.DaoVehicle;


import co.ct.model.Customer;
import co.ct.model.Vehicle;



@Controller
public class HomeController {

	DaoVehicle dh= new DaoVehicle();

	
	@RequestMapping("/")
	public String index() {
		System.out.println("here");
		return "index";
	}
	
	@RequestMapping("/index")
	public String indexlogout(HttpServletRequest request) {
		
		return this.signout(request);
	}
	
	
	@RequestMapping("/register")
	public ModelAndView register() {
		ModelAndView mv =new ModelAndView();
		mv.addObject("customer", new Customer());
		mv.setViewName("register");
	
		return mv;
	}
	
	
	@RequestMapping(method=RequestMethod.POST, value="/register")
	public String registerfinal(@Valid @ModelAttribute("customer") Customer customer,BindingResult br,HttpServletRequest request) {

		if (br.hasErrors()) {

			return "register";
		} else {
			if (dh.ifusernameexist(customer)) {
				String s = dh.register(customer);
				request.setAttribute("msg", s);
				return "index";
			}
			else {
				request.setAttribute("msg", "username already exist try another one");
				return "register";
			}
		}
	}

	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView mv =new ModelAndView();
		mv.addObject("customer", new Customer());
		mv.setViewName("login");
		return mv;
	}
	

	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String loginfinal( @Valid @ModelAttribute("customer") Customer customer,BindingResult br,HttpServletRequest request) {
	
		if(dh.login(customer)) {
			HttpSession session=request.getSession(true);
			session.setAttribute("cusName",customer.getUserName() );
			ArrayList<Vehicle> buylist=new ArrayList<Vehicle>();
			session.setAttribute("customer", customer);
			session.setAttribute("buylist",buylist );
			session.setAttribute("role", customer.getRole());
			
		return "front";
		}
	else {
		request.setAttribute("msg","incorrect username or password");
		return "login";
	}
	}
	@RequestMapping("/addvehicle")
	public ModelAndView addvehicle(HttpServletRequest request) {
		ModelAndView mv =new ModelAndView();
		
		if(request.getSession(false).getAttribute("cusName")!=null ) {
		
		mv.addObject("vehicle", new Vehicle());
		mv.setViewName("addvehicle");
		}
		else {
			mv.setViewName("index");
		
		}
		return mv;
	}
	
	private static final String UPLOAD_DIRECTORY ="/src/main/webapp/resources/images";  
	
	 public void uploadimage( @RequestParam CommonsMultipartFile file,  
	           HttpSession session) throws Exception{  
	  ServletContext context = session.getServletContext();  
	    String path = context.getContextPath();  
	  System.out.println(path);
	    String filename = file.getOriginalFilename();  
	   
	    byte[] bytes = file.getBytes();  
	    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(  
	    		"C:\\Users\\pranave\\Desktop\\"+path+ UPLOAD_DIRECTORY+File.separator+filename));  
	  //  System.out.println(path +File.separator+"resources/images/"+filename);
	    //"C:\\Users\\trainingvdi\\Desktop\\project"+
	    stream.write(bytes);  
	    stream.flush();  
	    stream.close();  
	           
	    
	    }  
	

	@RequestMapping(method=RequestMethod.POST,value="/addvehicle")
	public String addvehiclefinal(@RequestParam("file") CommonsMultipartFile file, @Valid 
	@ModelAttribute("vehicle") Vehicle vehicle, BindingResult br,HttpServletRequest request,HttpSession session) throws Exception {
		String imageName=file.getOriginalFilename();
		vehicle.setVehicleImageName(imageName);
		uploadimage(file,session);
		String s=dh.addVehicle(vehicle);
		System.out.println(s);
		request.setAttribute("msg","vehicle has been added and file uploaded successfully");
	return "front";
	}
	
	@RequestMapping("/getbyid")
	public ModelAndView getVehicleById(HttpServletRequest request) {
		ModelAndView mv =new ModelAndView();
		if(request.getSession(false).getAttribute("cusName")!=null) {
		mv.addObject("vehicle", new Vehicle());
		mv.setViewName("getbyid");}
		else {
			mv.setViewName("index");		
		}
		return mv;
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/getbyid")
	public String getVehicleByIdfinal(@ModelAttribute("vehicle") Vehicle vehicle,HttpSession session) {
		Vehicle vehicle1=dh.getVehicleById(vehicle);
		session.setAttribute("byidprint",vehicle1);
	return "getbyid";
	}
	
	@RequestMapping("/deletebyid")
	public ModelAndView deleteVehicleById(HttpServletRequest request) {
		ModelAndView mv =new ModelAndView();
		if(request.getSession(false).getAttribute("cusName")!=null) {
		mv.addObject("vehicle", new Vehicle());
		mv.setViewName("deletebyid");}
		else {
			mv.setViewName("index");	
		}
		
		return mv;
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/deletebyid")
	public String deleteVehicleByIdfinal(@ModelAttribute("vehicle") Vehicle vehicle,HttpServletRequest request) {
		String s=dh.deleteVehicle(vehicle);
		System.out.println(s);
		request.setAttribute("msg","vehicle has been deleted");
	return "front";
	}
	
	@RequestMapping("/displayall")
	public ModelAndView displayAll(HttpServletRequest request) {
		ModelAndView mv =new ModelAndView();
		if(request.getSession(false).getAttribute("cusName")!=null) {
		List<Vehicle> list =dh.displayAll();
		request.setAttribute("list", list);
		mv.setViewName( "displayall");}
		/*for(Vehicle v: list) {
			System.out.println(v+"\n");
		}*/
		else {
			mv.setViewName("index");	
		}
		
		return mv;
		
	}
	
	@RequestMapping("/front")
	public ModelAndView backtofront(HttpServletRequest request) {
		ModelAndView mv =new ModelAndView();
		if(request.getSession(false).getAttribute("cusName")!=null) {
		mv.setViewName("front");
		}
		else {
			mv.setViewName("index");	
		}
		
		return mv;
	}
	
	@RequestMapping("/signout")
	public String signout(HttpServletRequest request) {
		HttpSession session=request.getSession(false);
		session.removeAttribute("cusName");
		session.removeAttribute("buylist");
		session.invalidate();
		return "index";
	}
	
	/*@RequestMapping("/senditem")
	public ModelAndView addtobuy(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		if(request.getSession(false).getAttribute("cusName")!=null) {
			
			mv.addObject("vehicle", new Vehicle());			
			
			mv.setViewName("displayall");
		}
		else {
			mv.setViewName("index");	
		}
      return mv;
	}*/
	
	@RequestMapping("/senditem")
	public ModelAndView addtobuyfinal(@RequestParam("Vcode") int Vcode,@RequestParam("Vname") String Vname,
			@RequestParam("Vprice") double Vprice,@RequestParam("vehicleImageName") String vehicleImageName,HttpServletRequest request) {
		HttpSession session= request.getSession(false);
		ModelAndView mv =new ModelAndView();
		mv = displayAll(request);
		Vehicle vehicle=new Vehicle(Vcode, Vname, Vprice, vehicleImageName);
		ArrayList buylist=(ArrayList<Vehicle>)session.getAttribute("buylist");
		buylist.add(vehicle);
		session.setAttribute("bought", buylist);
		System.out.println(buylist);
		
		return mv;
	}
	
	@RequestMapping("/wishlist")
	public String wishlist(HttpSession session) {
		
	return "wishlist";
	}
	
	
	@RequestMapping("/deleteitem")
	public ModelAndView deleteitemfromlist(@RequestParam("Vcode") int Vcode,@RequestParam("Vname") String Vname,
			@RequestParam("Vprice") double Vprice,@RequestParam("vehicleImageName") String vehicleImageName,HttpServletRequest request) {
		HttpSession session= request.getSession(false);
		ModelAndView mv =new ModelAndView();
		//mv = displayAll(request);
		Vehicle vehicle=new Vehicle(Vcode, Vname, Vprice, vehicleImageName);
		ArrayList<Vehicle> buylist=(ArrayList<Vehicle>)session.getAttribute("buylist");
		System.out.println(vehicle);
		buylist.remove(0);
	//	System.out.println(delete);
		session.setAttribute("bought", buylist);
		System.out.println(buylist);
		mv.setViewName("wishlist");
		return mv;
	}
	
}
