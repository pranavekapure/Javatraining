package co.ct.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.validation.constraints.*;

import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;

import javax.persistence.*
;@Entity
@Table
public class Customer implements Serializable {
	@Id @GeneratedValue
	private Integer Id;
	
	@NotEmpty(message="Name Cannot be Empty")
	@Size(min=3,max=16,message="enter username greater than 3 upto 16 charecters")
	private String userName;
	@SuppressWarnings("deprecation")
	@NotEmpty(message="Name Cannot be Empty")
	@Size(min=3,max=16,message="enter password greater than 3 upto 16 charecters")
	
	private String password;
	
	private String role;
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Customer [Id=" + Id + ", userName=" + userName + ", password=" + password + ", role=" + role + "]";
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(Integer id, String userName, String password, String role) {
		super();
		Id = id;
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	
	
	
}
