package co.ct.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table
public class Vehicle {
	@Id @GeneratedValue
	private int Vcode;
	@NotEmpty(message=" product Name Cannot be Empty")
	@Size(min=3,max=16,message="enter name greater than 3 upto 16 charecters")
	private String Vname;
	@NotNull(message="PRODUCT price CANNOT BE EMPTY ")
	private Double Vprice;
	private String vehicleImageName;
	public int getVcode() {
		return Vcode;
	}
	public void setVcode(int vcode) {
		Vcode = vcode;
	}
	public Vehicle(int vcode, String vname, double vprice2, String vehicleImageName) {
		super();
		Vcode = vcode;
		Vname = vname;
		Vprice = vprice2;
		this.vehicleImageName = vehicleImageName;
	}
	public String getVname() {
		return Vname;
	}
	public void setVname(String vname) {
		Vname = vname;
	}
	public Double getVprice() {
		return Vprice;
	}
	public void setVprice(Double vprice) {
		Vprice = vprice;
	}
	public String getVehicleImageName() {
		return vehicleImageName;
	}
	public void setVehicleImageName(String vehicleImageName) {
		this.vehicleImageName = vehicleImageName;
	}
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Vehicle [Vcode=" + Vcode + ", Vname=" + Vname + ", Vprice=" + Vprice + ", vehicleImageName="
				+ vehicleImageName + "]";
	}
	
}
