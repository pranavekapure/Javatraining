import java.io.*; 
import java.util.*; 
public class ThreeDigit{
	public static void main (String...abc){
		int num=0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter a number");
		num = scanner.nextInt();
		scanner.close();
     		String p="";
		p=Concat.result(num);
		System.out.println(p);
		
	}
}
class Concat
{
	public static int e;
	public static String result(int n)
	{
		String[] arr=new String []{"zero","one","two","three","four","five","six","seven","eight","nine"};
		String[] arr1=new String []{"ten","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
		String[] arr2=new String []{"eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};	
		String d="";
  		
		for(int i=100;i>=1;i/=10){
			 		 e=n/i;
			if(i==100)
				{     
					if(e==0){i=10;break;}
					{d=d+arr[e]+" Hundred"+" and ";}
					
				}

			if(i==10)
				{
					if(e==1)
					{
					d=d+arr2[(n%10)-1];
					break;
					}
					d=d+arr1[e-1]+" ";
				}

			if(i==1)
				{
					if(e!=0)
					d=d+arr[e]+" ";
				}
			
				n=n%i;			
				}
		return d;
	}
}