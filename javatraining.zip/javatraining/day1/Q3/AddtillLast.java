import java.io.*; 
import java.util.*; 
public class AddtillLast{
	public static void main(String...abc){
		int num=0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter a number");
		num = scanner.nextInt();
		scanner.close();
		int p=Root.result(num);
		System.out.println("root number ="+p);

	}
}

class Root{
	public static int result(int a){
		if(a>=10){
			int r=Root.sum(a);
			a= Root.result(r);		
		}
		return a;
	}
	public static int sum(int z){
		int sum=0;
		if(z<10){sum=z;}
		else{
			while(z>=1){
				int s=z%10;
				sum=sum+s;
				z=z/10;
				}	
		    }
		return sum;
	}
}