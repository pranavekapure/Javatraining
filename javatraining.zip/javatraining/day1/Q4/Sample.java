import java.util.Scanner;
public class Sample {

	public static void main(String[] args) {
		 int num=0;int num1=0;int answer=0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter two numbers and press enter after entering each number");
		num = scanner.nextInt();
		num1 = scanner.nextInt();
 		scanner.close();
 	    answer=Result.multiplication(num,num1);
 	    System.out.println("multiplication ="+ answer);
 		

	}

}
 class Result { 
	public static int multiplication(int a,int b) {
		        int sum=0;
			System.out.println("entered numbers are "+a+","+b);
			for(int i=0;i<a;i++) {
				sum=sum+b;
			}
			return sum;
		}
}
