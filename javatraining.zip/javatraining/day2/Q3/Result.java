package practice4;

public class Result {
public static void main(String...abc) {
	Readvalue r1= new Readvalue(123,"Ramesh");
	System.out.println(r1.getRoll_no());
	System.out.println(r1.getBranch());
}
}

class Readvalue{
	private int roll_no;
	private String branch;
	Readvalue(){}
	Readvalue(int roll_no,String branch){   //write only ones read only
		this.roll_no=roll_no;
		this.branch=branch;
	}
	public int getRoll_no() {
		return roll_no;
	}
	
	public String getBranch() {
		return branch;
	}
	
	
}