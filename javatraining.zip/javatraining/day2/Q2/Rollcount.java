package practice4;
 class Count {
	 public static int i;
	  Count(){
	   i++;
  }
}

public class Rollcount {
	
	
	
	public static void main(String...abc) 
	{
		Count s1=new Count();
		Count s2=new Count();
		Count s3=new Count();
		System.out.println(Count.i);}
}
