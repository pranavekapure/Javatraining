package practice4;

 class Electro {
  void input() {
	  System.out.println("power");
  } 
  void processor() {
	  System.out.println("controller");
  } 
}

 class Radio extends Electro {
	  void audio() {
		  System.out.println("sound");
	  } 
	}

 class Telev extends Radio {
	  void video() {
		  System.out.println("football match ");
	  } 
	   
	}

class Projector extends Electro {
	  void display() {
		  System.out.println("picture");
	  } 
	  
	}

public class electronics{
	
	public static void main(String...abc) {
		Radio r1= new Radio();
		Telev t1= new Telev();
		Projector p1= new Projector();
		r1.audio();
		r1.input();
		t1.video();
		t1.processor();
		p1.display();
		p1.input();
	}
}
