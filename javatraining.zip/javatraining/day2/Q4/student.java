package practice4;

public class student {
public static void main(String...abc)
{
	DaysSc d1= new DaysSc();
	Hosteller h1= new Hosteller();
	h1.collegefees();
	d1.collegefees();
	h1.hostelfees();
	d1.trainpass();
	
}
}
class Parent {
	void collegefees() {
		System.out.println("college fees paid");
	}
}

class DaysSc extends Parent{
	void trainpass() {
		System.out.println("ticket local");
	}
}
class Hosteller extends Parent{
	void hostelfees() {
		System.out.println("paid hostel fees");
	}
}
